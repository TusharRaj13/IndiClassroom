const app_config = {
    "mongo_uri":"mongodb+srv://tushar_mongodb:tNO1lobJDsCXUwuR@cluster0.4u9za.mongodb.net/indiclassroom?retryWrites=true&w=majority",
    "google_client_id":"472316975840-fmnd8aqglnoqn89q696fe105g0m6v82s.apps.googleusercontent.com",
    "google_client_secret":"GYWWtEO_he31tQbGPce3he5x",
    "google_outh_fetch":"https://oauth2.googleapis.com/tokeninfo?id_token="
}

module.exports = app_config;