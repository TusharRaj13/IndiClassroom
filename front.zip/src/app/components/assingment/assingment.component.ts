import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assingment',
  templateUrl: './assingment.component.html',
  styleUrls: ['./assingment.component.css']
})
export class AssingmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
